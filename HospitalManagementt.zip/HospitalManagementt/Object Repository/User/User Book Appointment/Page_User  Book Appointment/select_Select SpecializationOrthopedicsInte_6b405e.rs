<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Select SpecializationOrthopedicsInte_6b405e</name>
   <tag></tag>
   <elementGuidId>b96a8bcc-27b4-4b67-967d-9d1bcdeebd10</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>select[name=&quot;Doctorspecialization&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@name='Doctorspecialization']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>select[name=&quot;Doctorspecialization&quot;]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>4622945d-d94a-4be6-b474-46147cf624bf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>Doctorspecialization</value>
      <webElementGuid>90f45fb0-4012-4a77-8841-bc2b7b3c339f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
      <webElementGuid>bc77c04d-5e45-49c6-9077-0ee0a01e80a4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onchange</name>
      <type>Main</type>
      <value>getdoctor(this.value);</value>
      <webElementGuid>598501a9-7e6a-4fc6-94c5-b552852fd38c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>required</name>
      <type>Main</type>
      <value>required</value>
      <webElementGuid>536e9972-c0ac-4daf-83b6-157757c08694</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
																Select Specialization
																
																	Orthopedics																
																																
																	Internal Medicine																
																																
																	Obstetrics and Gynecology																
																																
																	Dermatology																
																																
																	Pediatrics																
																																
																	Radiology																
																																
																	General Surgery																
																																
																	Ophthalmology																
																																
																	Anesthesia																
																																
																	Pathology																
																																
																	ENT																
																																
																	Dental Care																
																																
																	Dermatologists																
																																
																	Endocrinologists																
																																
																	Neurologists																
																																
															</value>
      <webElementGuid>0760d6d3-7e75-4de7-9d26-e1a12943c2d2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;container&quot;)/div[@class=&quot;container-fluid container-fullw bg-white&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;row margin-top-30&quot;]/div[@class=&quot;col-lg-8 col-md-12&quot;]/div[@class=&quot;panel panel-white&quot;]/div[@class=&quot;panel-body&quot;]/form[1]/div[@class=&quot;form-group&quot;]/select[@class=&quot;form-control&quot;]</value>
      <webElementGuid>f3955c99-c61f-4a1c-ab5d-a9419d8e2710</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@name='Doctorspecialization']</value>
      <webElementGuid>f35a801a-50ea-4500-b074-1dab5fdba738</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='container']/div/div/div/div/div/div/div[2]/form/div/select</value>
      <webElementGuid>3a09a992-2785-41b0-87f8-809834a9c5c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Doctor Specialization'])[1]/following::select[1]</value>
      <webElementGuid>114075ca-5e73-4a57-afc2-3ddc45cb6f42</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Book Appointment'])[3]/following::select[1]</value>
      <webElementGuid>889f1647-6b10-4418-a7e6-7e846f66d654</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Doctors'])[1]/preceding::select[1]</value>
      <webElementGuid>6f513085-3563-4ec2-ad46-0dabf8331460</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Consultancy Fees'])[1]/preceding::select[2]</value>
      <webElementGuid>b339586f-7b85-4830-8caa-679857330cd9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>0e2d02ed-e72e-4592-bec5-98eb5e8e0626</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'Doctorspecialization' and (text() = '
																Select Specialization
																
																	Orthopedics																
																																
																	Internal Medicine																
																																
																	Obstetrics and Gynecology																
																																
																	Dermatology																
																																
																	Pediatrics																
																																
																	Radiology																
																																
																	General Surgery																
																																
																	Ophthalmology																
																																
																	Anesthesia																
																																
																	Pathology																
																																
																	ENT																
																																
																	Dental Care																
																																
																	Dermatologists																
																																
																	Endocrinologists																
																																
																	Neurologists																
																																
															' or . = '
																Select Specialization
																
																	Orthopedics																
																																
																	Internal Medicine																
																																
																	Obstetrics and Gynecology																
																																
																	Dermatology																
																																
																	Pediatrics																
																																
																	Radiology																
																																
																	General Surgery																
																																
																	Ophthalmology																
																																
																	Anesthesia																
																																
																	Pathology																
																																
																	ENT																
																																
																	Dental Care																
																																
																	Dermatologists																
																																
																	Endocrinologists																
																																
																	Neurologists																
																																
															')]</value>
      <webElementGuid>f46138d9-707b-48c5-a28a-753c5e3939db</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
