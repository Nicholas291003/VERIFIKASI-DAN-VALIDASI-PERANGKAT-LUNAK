<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>form_Doctor SpecializationSelect Specializa_9e3f18</name>
   <tag></tag>
   <elementGuidId>fc67e199-9bfa-47fe-b6c1-385a12ed965b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>form[name=&quot;book&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@name='book']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=form</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>form</value>
      <webElementGuid>841b57f2-d099-44b8-8041-787f69c32e2d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>form</value>
      <webElementGuid>a490be62-f6e0-4ebe-a417-3f3b10237e60</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>book</value>
      <webElementGuid>d73f1129-a2f7-43b1-958b-9ea8728f32ea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>method</name>
      <type>Main</type>
      <value>post</value>
      <webElementGuid>439c255e-7d28-42c9-8eff-3f8b847eab32</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
														



															
																Doctor Specialization
															
							
																Select Specialization
																
																	Orthopedics																
																																
																	Internal Medicine																
																																
																	Obstetrics and Gynecology																
																																
																	Dermatology																
																																
																	Pediatrics																
																																
																	Radiology																
																																
																	General Surgery																
																																
																	Ophthalmology																
																																
																	Anesthesia																
																																
																	Pathology																
																																
																	ENT																
																																
																	Dental Care																
																																
																	Dermatologists																
																																
																	Endocrinologists																
																																
																	Neurologists																
																																
															
														




														
															
																Doctors
															
						 Select Doctor 
   Anuj kumar
  

														





														
															
																Consultancy Fees
															
					 500
  

														
														

															
																Date
															

	
														
														

															
														
														Time
													
															
			eg : 10:00 PM
																												
														
														
															Submit
														
													</value>
      <webElementGuid>c0e374e3-e705-4c04-8200-0bd27fa70c3e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;container&quot;)/div[@class=&quot;container-fluid container-fullw bg-white&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;row margin-top-30&quot;]/div[@class=&quot;col-lg-8 col-md-12&quot;]/div[@class=&quot;panel panel-white&quot;]/div[@class=&quot;panel-body&quot;]/form[1]</value>
      <webElementGuid>81533210-0084-4603-9e4f-7796977198ed</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//form[@name='book']</value>
      <webElementGuid>982f25bb-ed97-47a4-85ad-c73dae8098c4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='container']/div/div/div/div/div/div/div[2]/form</value>
      <webElementGuid>a2cabf2f-d5e8-4623-89da-350b205d5ddd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Book Appointment'])[3]/following::form[1]</value>
      <webElementGuid>3308a78e-6b16-4f64-b230-de8d911c05f2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Book Appointment'])[2]/following::form[1]</value>
      <webElementGuid>0b3bd29a-d8c0-456e-b0d9-8054fb4a777d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form</value>
      <webElementGuid>4a808ac8-77a7-4e17-9e60-28650f11f0de</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//form[@name = 'book' and (text() = '
														



															
																Doctor Specialization
															
							
																Select Specialization
																
																	Orthopedics																
																																
																	Internal Medicine																
																																
																	Obstetrics and Gynecology																
																																
																	Dermatology																
																																
																	Pediatrics																
																																
																	Radiology																
																																
																	General Surgery																
																																
																	Ophthalmology																
																																
																	Anesthesia																
																																
																	Pathology																
																																
																	ENT																
																																
																	Dental Care																
																																
																	Dermatologists																
																																
																	Endocrinologists																
																																
																	Neurologists																
																																
															
														




														
															
																Doctors
															
						 Select Doctor 
   Anuj kumar
  

														





														
															
																Consultancy Fees
															
					 500
  

														
														

															
																Date
															

	
														
														

															
														
														Time
													
															
			eg : 10:00 PM
																												
														
														
															Submit
														
													' or . = '
														



															
																Doctor Specialization
															
							
																Select Specialization
																
																	Orthopedics																
																																
																	Internal Medicine																
																																
																	Obstetrics and Gynecology																
																																
																	Dermatology																
																																
																	Pediatrics																
																																
																	Radiology																
																																
																	General Surgery																
																																
																	Ophthalmology																
																																
																	Anesthesia																
																																
																	Pathology																
																																
																	ENT																
																																
																	Dental Care																
																																
																	Dermatologists																
																																
																	Endocrinologists																
																																
																	Neurologists																
																																
															
														




														
															
																Doctors
															
						 Select Doctor 
   Anuj kumar
  

														





														
															
																Consultancy Fees
															
					 500
  

														
														

															
																Date
															

	
														
														

															
														
														Time
													
															
			eg : 10:00 PM
																												
														
														
															Submit
														
													')]</value>
      <webElementGuid>51d127dd-4d4a-4d2d-a07d-9290931388ca</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
