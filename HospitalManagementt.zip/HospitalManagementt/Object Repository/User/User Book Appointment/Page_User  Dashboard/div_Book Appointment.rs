<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Book Appointment</name>
   <tag></tag>
   <elementGuidId>1fc9c973-b0e5-4805-aac9-a31596b68485</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(2) > a > div.item-content > div.item-inner</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='sidebar']/div/nav/ul/li[2]/a/div/div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot; Book Appointment&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>449c8d22-b747-4afa-bf0c-2822a5666d5e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>item-inner</value>
      <webElementGuid>6c61f2de-220b-4972-8438-33dd7bc1c3a0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
											 Book Appointment 
										</value>
      <webElementGuid>e3eedf98-5084-41ec-b5af-86b7bd6b8e6d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sidebar&quot;)/div[@class=&quot;sidebar-container perfect-scrollbar ps-container&quot;]/nav[1]/ul[@class=&quot;main-navigation-menu&quot;]/li[2]/a[1]/div[@class=&quot;item-content&quot;]/div[@class=&quot;item-inner&quot;]</value>
      <webElementGuid>1e3d3dfb-2cb6-4a80-b875-c4994f5c97b0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='sidebar']/div/nav/ul/li[2]/a/div/div[2]</value>
      <webElementGuid>f05c59bc-4d2e-473c-b56f-838cc7b3708a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/following::div[3]</value>
      <webElementGuid>60fefcf8-7e9e-4674-87f6-ac3579fe6172</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Main Navigation'])[1]/following::div[6]</value>
      <webElementGuid>9f87d546-ecec-411d-82d2-6668d4a58d08</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Appointment History'])[1]/preceding::div[2]</value>
      <webElementGuid>df9e6a09-d62c-4878-9499-5563fa7d6c6c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/a/div/div[2]</value>
      <webElementGuid>0fa70cfa-2663-48b7-8b9f-111cbfb93b56</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
											 Book Appointment 
										' or . = '
											 Book Appointment 
										')]</value>
      <webElementGuid>6f83cc89-06a2-43ef-8039-9efd0f4605d7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
