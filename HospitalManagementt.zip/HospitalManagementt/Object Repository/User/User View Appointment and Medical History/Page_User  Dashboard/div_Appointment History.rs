<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Appointment History</name>
   <tag></tag>
   <elementGuidId>732b0fcc-e99f-4912-9950-78a61101d3f5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(3) > a > div.item-content > div.item-inner</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='sidebar']/div/nav/ul/li[3]/a/div/div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot; Appointment History&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>ff2f587b-cf38-4bab-93f3-35ae3c7c6c4f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>item-inner</value>
      <webElementGuid>011deb36-d2cb-4343-9236-f4549a101c87</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
											 Appointment History 
										</value>
      <webElementGuid>58648905-ea8e-4897-b399-015ddef6e0c3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sidebar&quot;)/div[@class=&quot;sidebar-container perfect-scrollbar ps-container&quot;]/nav[1]/ul[@class=&quot;main-navigation-menu&quot;]/li[3]/a[1]/div[@class=&quot;item-content&quot;]/div[@class=&quot;item-inner&quot;]</value>
      <webElementGuid>fd237049-649f-48b7-8093-41f0349c2935</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='sidebar']/div/nav/ul/li[3]/a/div/div[2]</value>
      <webElementGuid>b3c5f73e-15f6-4474-afcd-431f5813fa5b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Book Appointment'])[1]/following::div[3]</value>
      <webElementGuid>6433faf0-52ef-42a3-9b03-856d3ac35c65</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/following::div[6]</value>
      <webElementGuid>e0f86bb7-38a6-4ce1-be3e-422534c62c56</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Medical History'])[1]/preceding::div[2]</value>
      <webElementGuid>fc9b66d5-4059-472c-9c0c-71b325482ef9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[3]/a/div/div[2]</value>
      <webElementGuid>c2ca6a83-9286-4ef8-b76e-205209f6c2b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
											 Appointment History 
										' or . = '
											 Appointment History 
										')]</value>
      <webElementGuid>49a4b972-8f69-466d-9904-052d4704696f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
