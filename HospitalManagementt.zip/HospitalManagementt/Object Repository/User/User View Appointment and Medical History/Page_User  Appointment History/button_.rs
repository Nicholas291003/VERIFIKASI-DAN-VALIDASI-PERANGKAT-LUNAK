<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_</name>
   <tag></tag>
   <elementGuidId>26c07bfa-5600-4135-a4f7-3a16806b6f9a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.btn.btn-primary.btn-o.btn-sm.dropdown-toggle</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@type='button']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=row[name=&quot;1. Anuj kumar ENT 500 2026-01-11 / 10:45 AM 2026-01-01 10:44:33 Active &quot;i] >> internal:role=button</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>fedc14bd-11ac-4d20-9f3f-efe2899fef95</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>9f396780-b0fb-4009-bc83-665184d56a78</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-primary btn-o btn-sm dropdown-toggle</value>
      <webElementGuid>035a5a10-c2df-475b-a268-c8f84749322f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
															 
														</value>
      <webElementGuid>3a7f6abc-6f89-4a2b-b714-336bc94b5fc0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sample-table-1&quot;)/tbody[1]/tr[1]/td[8]/div[@class=&quot;visible-xs visible-sm hidden-md hidden-lg&quot;]/div[@class=&quot;btn-group&quot;]/button[@class=&quot;btn btn-primary btn-o btn-sm dropdown-toggle&quot;]</value>
      <webElementGuid>a718d34e-0de9-400d-ba1a-d2f11281a5d0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//button[@type='button']</value>
      <webElementGuid>1b49cd9b-d843-44d1-8c98-ca09968675ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//table[@id='sample-table-1']/tbody/tr/td[8]/div[2]/div/button</value>
      <webElementGuid>04fc4bb4-f677-4ad9-83a1-1c6feacfd58b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[1]/following::button[1]</value>
      <webElementGuid>549d0a44-f8ed-44d4-b446-795ab0c9e303</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Active'])[1]/following::button[1]</value>
      <webElementGuid>aed5ea60-aecd-4454-bb8c-2e5bf6957124</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dr. Andi Wijaya, Sp.OT'])[1]/preceding::button[1]</value>
      <webElementGuid>62c82e43-9ce8-4d47-ad5f-29f8371d082a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Orthopedics'])[1]/preceding::button[1]</value>
      <webElementGuid>83aefe97-43c7-4ab6-b47b-2770a87abe34</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button</value>
      <webElementGuid>f5e95179-ec88-4124-950a-9a5b5df265ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[@type = 'button' and (text() = '
															 
														' or . = '
															 
														')]</value>
      <webElementGuid>9ec38c60-cb7d-4378-82d4-79315c6a93f4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
