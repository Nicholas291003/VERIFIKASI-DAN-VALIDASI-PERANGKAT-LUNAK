<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Medical History</name>
   <tag></tag>
   <elementGuidId>bc8822cc-7cd9-4d46-b15c-d2e8704e2385</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(4) > a > div.item-content > div.item-inner > span.title</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='sidebar']/div/nav/ul/li[4]/a/div/div[2]/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot; Medical History&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>ca21c27c-5122-4b32-ad8e-2fdbdfa7b2c4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>title</value>
      <webElementGuid>15a4dbe6-0121-419f-9008-158fe79e4355</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Medical History </value>
      <webElementGuid>8076e64b-f410-48b5-a61f-a7607a2b4bcb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sidebar&quot;)/div[@class=&quot;sidebar-container perfect-scrollbar ps-container&quot;]/nav[1]/ul[@class=&quot;main-navigation-menu&quot;]/li[4]/a[1]/div[@class=&quot;item-content&quot;]/div[@class=&quot;item-inner&quot;]/span[@class=&quot;title&quot;]</value>
      <webElementGuid>02187aff-2109-4a2b-a72d-8d3396b0676f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='sidebar']/div/nav/ul/li[4]/a/div/div[2]/span</value>
      <webElementGuid>1ed6034d-4416-478f-adad-a5a413ef297a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Appointment History'])[1]/following::span[1]</value>
      <webElementGuid>bc1df789-d1ff-461e-9889-258d9bf1b52b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Book Appointment'])[1]/following::span[2]</value>
      <webElementGuid>8f138d56-2ca9-4def-a754-648c1b625461</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='HMS'])[1]/preceding::span[1]</value>
      <webElementGuid>62d85d0f-3c52-4019-86d4-c999869aca09</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Toggle navigation'])[1]/preceding::span[1]</value>
      <webElementGuid>b3bc462e-c16b-46e4-a6f2-405d31cf60b5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Medical History']/parent::*</value>
      <webElementGuid>9e1abb86-932c-44b1-8056-bda9c3d18560</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[4]/a/div/div[2]/span</value>
      <webElementGuid>9aed78f7-53a9-4259-81be-603292a30cea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = ' Medical History ' or . = ' Medical History ')]</value>
      <webElementGuid>12f4e1bf-0778-4a21-9b26-363ac4f544a7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
