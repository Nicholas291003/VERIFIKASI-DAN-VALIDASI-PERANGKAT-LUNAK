<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Main Navigation Dashboard  Book Appoint_d0092c</name>
   <tag></tag>
   <elementGuidId>21062bfb-ef6e-41c3-89f0-7c43b37a3659</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#app</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='app']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Main Navigation Dashboard Book Appointment Appointment History Medical History H&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>b0e0e525-ca79-4f51-8f9a-bf1fbf51eed0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>app</value>
      <webElementGuid>d4dbca9e-9247-4183-bca5-3e1e5967517a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>app-navbar-fixed app-sidebar-fixed</value>
      <webElementGuid>d78b4bb7-86b1-415d-8def-815e7154fb98</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>		

				


						
						
						
							Main Navigation
						
						
							
								
									
										
											
										
										
											 Dashboard 
										
									
								
							
							
								
									
										
											
										
										
											 Book Appointment 
										
									
								
							

							
								
									
										
											
										
										
											 Appointment History 
										
									
								
							

								
									
										
											
										
										
											 Medical History 
										
									
								
							

						
						
						
					
					
						
				

					
					
					
						
							
						
						
							HMS
						
						
							
						
						
							Toggle navigation
							
						
					
					
					
					
						
							
								
								Hospital Management System
							
						
						
							
								
									 



									nicholas aditya 
								
								
									
										
											My Profile
										
									
								
									
										
											Change Password
										
									
									
										
											Log Out
										
									
								
							
							
						
						
						
							
							
						
						
					
				
					
					
				
				
				
					
						
						
							
								
									User  | Appointment History
																	
								
									
										User 
									
									
										Appointment History
									
								
							
						
						
						
						
						

									
								
									
									Your appointment canceled !!									
									
										
											
												#
												Doctor Name
												Specialization
												Consultancy Fee
												Appointment Date / Time 
												Appointment Creation Date  
												Current Status
												Action
												
											
										
										

											
												1.
												Anuj kumar
												ENT
												500
												2026-01-11 / 10:45 AM												
												2026-01-01 10:44:33
												
Cancel by You
												
												
							Canceled												
												
													
														
															 
														
														
															
																
																	Edit
																
															
															
																
																	Share
																
															
															
																
																	Remove
																
															
														
													
												
											
											
											
											
												2.
												Dr. Andi Wijaya, Sp.OT
												Orthopedics
												300000
												2026-01-15 / 1:00 PM												
												2025-12-31 11:58:01
												
Cancel by You
												
												
							Canceled												
												
													
														
															 
														
														
															
																
																	Edit
																
															
															
																
																	Share
																
															
															
																
																	Remove
																
															
														
													
												
											
											
																						
											
										
									
								
							
								
						
						
						
						
					
				
			
			
	
				
					
			 Hospital Management System
					
					
						
					
				
						
		
			
	
				
				
					Style Selector
				
				
					
					
						 Fixed header
						
							
						
					
					
					
					
						Fixed sidebar
						
							
						
					
					
					
					
						Closed sidebar
						
							
						
					
					
					
					
						Fixed footer
						
							
						
					
					
					
					
						
							
								
									
									
									   
									   
								
							
						
						
							
								
									
									
									   
									   
								
							
						
					
					
						
							
								
									
									
									   
									   
								
							
						
						
							
								
									
									
									   
									   
								
							
						
					
					
						
							
								
									
									
									   
									   
								
							
						
						
							
								
									
									
									   
									   
								
							
						
					
					
				
						
			
		</value>
      <webElementGuid>8d81946d-a761-4fe8-9c34-65f47788e626</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)</value>
      <webElementGuid>a0c7213a-526c-4fcc-b718-7ef352a20930</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='app']</value>
      <webElementGuid>7d21f156-77f9-46bb-b68b-531e356e0c69</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div</value>
      <webElementGuid>a25e6246-0077-4508-bafd-bc98fd1589e3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[@id = 'app' and (text() = '		

				


						
						
						
							Main Navigation
						
						
							
								
									
										
											
										
										
											 Dashboard 
										
									
								
							
							
								
									
										
											
										
										
											 Book Appointment 
										
									
								
							

							
								
									
										
											
										
										
											 Appointment History 
										
									
								
							

								
									
										
											
										
										
											 Medical History 
										
									
								
							

						
						
						
					
					
						
				

					
					
					
						
							
						
						
							HMS
						
						
							
						
						
							Toggle navigation
							
						
					
					
					
					
						
							
								
								Hospital Management System
							
						
						
							
								
									 



									nicholas aditya 
								
								
									
										
											My Profile
										
									
								
									
										
											Change Password
										
									
									
										
											Log Out
										
									
								
							
							
						
						
						
							
							
						
						
					
				
					
					
				
				
				
					
						
						
							
								
									User  | Appointment History
																	
								
									
										User 
									
									
										Appointment History
									
								
							
						
						
						
						
						

									
								
									
									Your appointment canceled !!									
									
										
											
												#
												Doctor Name
												Specialization
												Consultancy Fee
												Appointment Date / Time 
												Appointment Creation Date  
												Current Status
												Action
												
											
										
										

											
												1.
												Anuj kumar
												ENT
												500
												2026-01-11 / 10:45 AM												
												2026-01-01 10:44:33
												
Cancel by You
												
												
							Canceled												
												
													
														
															 
														
														
															
																
																	Edit
																
															
															
																
																	Share
																
															
															
																
																	Remove
																
															
														
													
												
											
											
											
											
												2.
												Dr. Andi Wijaya, Sp.OT
												Orthopedics
												300000
												2026-01-15 / 1:00 PM												
												2025-12-31 11:58:01
												
Cancel by You
												
												
							Canceled												
												
													
														
															 
														
														
															
																
																	Edit
																
															
															
																
																	Share
																
															
															
																
																	Remove
																
															
														
													
												
											
											
																						
											
										
									
								
							
								
						
						
						
						
					
				
			
			
	
				
					
			 Hospital Management System
					
					
						
					
				
						
		
			
	
				
				
					Style Selector
				
				
					
					
						 Fixed header
						
							
						
					
					
					
					
						Fixed sidebar
						
							
						
					
					
					
					
						Closed sidebar
						
							
						
					
					
					
					
						Fixed footer
						
							
						
					
					
					
					
						
							
								
									
									
									   
									   
								
							
						
						
							
								
									
									
									   
									   
								
							
						
					
					
						
							
								
									
									
									   
									   
								
							
						
						
							
								
									
									
									   
									   
								
							
						
					
					
						
							
								
									
									
									   
									   
								
							
						
						
							
								
									
									
									   
									   
								
							
						
					
					
				
						
			
		' or . = '		

				


						
						
						
							Main Navigation
						
						
							
								
									
										
											
										
										
											 Dashboard 
										
									
								
							
							
								
									
										
											
										
										
											 Book Appointment 
										
									
								
							

							
								
									
										
											
										
										
											 Appointment History 
										
									
								
							

								
									
										
											
										
										
											 Medical History 
										
									
								
							

						
						
						
					
					
						
				

					
					
					
						
							
						
						
							HMS
						
						
							
						
						
							Toggle navigation
							
						
					
					
					
					
						
							
								
								Hospital Management System
							
						
						
							
								
									 



									nicholas aditya 
								
								
									
										
											My Profile
										
									
								
									
										
											Change Password
										
									
									
										
											Log Out
										
									
								
							
							
						
						
						
							
							
						
						
					
				
					
					
				
				
				
					
						
						
							
								
									User  | Appointment History
																	
								
									
										User 
									
									
										Appointment History
									
								
							
						
						
						
						
						

									
								
									
									Your appointment canceled !!									
									
										
											
												#
												Doctor Name
												Specialization
												Consultancy Fee
												Appointment Date / Time 
												Appointment Creation Date  
												Current Status
												Action
												
											
										
										

											
												1.
												Anuj kumar
												ENT
												500
												2026-01-11 / 10:45 AM												
												2026-01-01 10:44:33
												
Cancel by You
												
												
							Canceled												
												
													
														
															 
														
														
															
																
																	Edit
																
															
															
																
																	Share
																
															
															
																
																	Remove
																
															
														
													
												
											
											
											
											
												2.
												Dr. Andi Wijaya, Sp.OT
												Orthopedics
												300000
												2026-01-15 / 1:00 PM												
												2025-12-31 11:58:01
												
Cancel by You
												
												
							Canceled												
												
													
														
															 
														
														
															
																
																	Edit
																
															
															
																
																	Share
																
															
															
																
																	Remove
																
															
														
													
												
											
											
																						
											
										
									
								
							
								
						
						
						
						
					
				
			
			
	
				
					
			 Hospital Management System
					
					
						
					
				
						
		
			
	
				
				
					Style Selector
				
				
					
					
						 Fixed header
						
							
						
					
					
					
					
						Fixed sidebar
						
							
						
					
					
					
					
						Closed sidebar
						
							
						
					
					
					
					
						Fixed footer
						
							
						
					
					
					
					
						
							
								
									
									
									   
									   
								
							
						
						
							
								
									
									
									   
									   
								
							
						
					
					
						
							
								
									
									
									   
									   
								
							
						
						
							
								
									
									
									   
									   
								
							
						
					
					
						
							
								
									
									
									   
									   
								
							
						
						
							
								
									
									
									   
									   
								
							
						
					
					
				
						
			
		')]</value>
      <webElementGuid>69cfc891-c48b-4fc4-9398-feb06528c9da</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
