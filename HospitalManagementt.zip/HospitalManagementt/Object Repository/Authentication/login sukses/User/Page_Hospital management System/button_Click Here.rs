<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Click Here</name>
   <tag></tag>
   <elementGuidId>c5caa54f-9f92-4fff-a7d6-95deb115d134</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.btn.btn-success.btn-sm</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='logins']/div/div[2]/div/div/div/div/a/button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;Click Here&quot;i] >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>4e02444b-cf22-4c0b-941f-46a1e501119a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-success btn-sm</value>
      <webElementGuid>c7dc362e-dbac-46c4-9fcc-75a92e33dfa4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Click Here</value>
      <webElementGuid>bb89d71d-e51b-49e2-982c-02a23d19c866</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;logins&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;col-sm-12 blog-cont&quot;]/div[@class=&quot;row no-margin&quot;]/div[@class=&quot;col-sm-4 blog-smk&quot;]/div[@class=&quot;blog-single&quot;]/div[@class=&quot;blog-single-det&quot;]/a[1]/button[@class=&quot;btn btn-success btn-sm&quot;]</value>
      <webElementGuid>04119196-b0bf-46a4-ade5-1f25948183d6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='logins']/div/div[2]/div/div/div/div/a/button</value>
      <webElementGuid>417583cb-f180-431c-8a00-e0821a4251ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Patient Login'])[1]/following::button[1]</value>
      <webElementGuid>0743a3a3-ef68-42aa-b97f-36a84a1ecbc8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Logins'])[2]/following::button[1]</value>
      <webElementGuid>73ebc620-8b33-4415-a2a3-b88a0f404579</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Doctors login'])[1]/preceding::button[1]</value>
      <webElementGuid>dca0ec0f-f5ee-438e-b0a5-a2d22441b891</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click Here'])[2]/preceding::button[1]</value>
      <webElementGuid>e4ca107d-31be-4928-8949-9b2d7b027cdc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Click Here']/parent::*</value>
      <webElementGuid>a5136942-7ff8-4091-9c4a-c3ed4481a89a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button</value>
      <webElementGuid>92ca8870-26a6-4a42-afcf-6da911a35976</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Click Here' or . = 'Click Here')]</value>
      <webElementGuid>94fe0a95-5075-4dbd-baef-53f347cab00c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
