<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Click Here</name>
   <tag></tag>
   <elementGuidId>9406b3d8-f403-4308-aa03-310904a03a0e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='logins']/div/div[2]/div/div[3]/div/div/a/button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;Click Here&quot;i] >> nth=2</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>b9b34b43-5ed8-48c4-8fd1-a4fdf9eb8660</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-success btn-sm</value>
      <webElementGuid>36fc3b0f-628b-403a-923c-0bc866466a3f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Click Here</value>
      <webElementGuid>f110ac22-f284-45cc-b852-79c662252850</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;logins&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;col-sm-12 blog-cont&quot;]/div[@class=&quot;row no-margin&quot;]/div[@class=&quot;col-sm-4 blog-smk&quot;]/div[@class=&quot;blog-single&quot;]/div[@class=&quot;blog-single-det&quot;]/a[1]/button[@class=&quot;btn btn-success btn-sm&quot;]</value>
      <webElementGuid>39cfeeeb-4f33-441d-87dd-e3f47a8b8776</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='logins']/div/div[2]/div/div[3]/div/div/a/button</value>
      <webElementGuid>fddd5e58-df55-4bad-a2a3-908bb400a0b9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Admin Login'])[1]/following::button[1]</value>
      <webElementGuid>c099a194-37b6-4826-8869-f2c456be6a2e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click Here'])[2]/following::button[1]</value>
      <webElementGuid>d9c650ed-1e7f-46d6-8b9c-719f967c4b63</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Our Key Features'])[1]/preceding::button[1]</value>
      <webElementGuid>bca91993-fba6-4f9d-91d0-a4e8910c8cb2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cardiology'])[1]/preceding::button[1]</value>
      <webElementGuid>49848786-64b7-4baa-b1bc-af593b82dbd2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/a/button</value>
      <webElementGuid>50d60c95-9e15-409e-8429-4f120f834b0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Click Here' or . = 'Click Here')]</value>
      <webElementGuid>ca97daa4-1da9-47ae-bc1b-a83631be8bf8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
