<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>fieldset_Sign in to your accountPlease ente_37a0d7</name>
   <tag></tag>
   <elementGuidId>a9d3405f-13c6-447f-8f5a-86742adee3fd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>fieldset</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Admin Login'])[1]/following::fieldset[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=group[name=&quot;Sign in to your account&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>fieldset</value>
      <webElementGuid>89dc97af-55c3-4cbc-98d6-f056945c20ac</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
							
								Sign in to your account
							
							
								Please enter your name and password to log in.
								Invalid username or password
							
							
								
									
									 
							
							
								
									
									 
							
							
								
								
									Login 
								
							
							Bacto Home Page
							
						</value>
      <webElementGuid>cd3a5268-1cd6-47ed-a188-1c9a33c9f2af</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths&quot;]/body[@class=&quot;login&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;main-login col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4&quot;]/div[@class=&quot;box-login&quot;]/form[@class=&quot;form-login&quot;]/fieldset[1]</value>
      <webElementGuid>9961c2d5-9bf1-4cfb-a4ad-76fb4d692481</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Admin Login'])[1]/following::fieldset[1]</value>
      <webElementGuid>12bd5a16-cafe-43ae-aaa1-863a07f0dd22</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//fieldset</value>
      <webElementGuid>7c968c16-4833-4fba-83de-fc6ba61e7cf4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//fieldset[(text() = '
							
								Sign in to your account
							
							
								Please enter your name and password to log in.
								Invalid username or password
							
							
								
									
									 
							
							
								
									
									 
							
							
								
								
									Login 
								
							
							Bacto Home Page
							
						' or . = '
							
								Sign in to your account
							
							
								Please enter your name and password to log in.
								Invalid username or password
							
							
								
									
									 
							
							
								
									
									 
							
							
								
								
									Login 
								
							
							Bacto Home Page
							
						')]</value>
      <webElementGuid>8c5a0be9-a85e-49bf-adb1-b2718f089b60</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
