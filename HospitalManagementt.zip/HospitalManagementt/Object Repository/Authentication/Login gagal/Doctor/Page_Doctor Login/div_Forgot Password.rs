<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Forgot Password</name>
   <tag></tag>
   <elementGuidId>aa3d4656-fc34-430c-9bf0-87bdca37ec79</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.form-group.form-actions</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign in to your account'])[1]/following::div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=group >> div >> internal:has-text=&quot;Forgot Password ?&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>bbc4241a-2122-4dcc-b958-9e896941f5e2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-group form-actions</value>
      <webElementGuid>470e51c4-63ae-43b1-a0ee-91736245b91a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
								
									
									
									 
									 
									Forgot Password ?
								
							</value>
      <webElementGuid>03a8894a-6e4b-47df-b126-13e686eb0f8a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths&quot;]/body[@class=&quot;login&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;main-login col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4&quot;]/div[@class=&quot;box-login&quot;]/form[@class=&quot;form-login&quot;]/fieldset[1]/div[@class=&quot;form-group form-actions&quot;]</value>
      <webElementGuid>7c159796-8791-4250-b66f-76b5baa32716</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign in to your account'])[1]/following::div[2]</value>
      <webElementGuid>136baec0-7101-47a8-812f-0f50874570bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='HMS | Doctor Login'])[1]/following::div[3]</value>
      <webElementGuid>19a7a907-fff2-4bcd-b360-ec13f28edfdc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[1]/preceding::div[1]</value>
      <webElementGuid>45147591-141f-41ea-bf8c-7974d782a66d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//fieldset/div[2]</value>
      <webElementGuid>4d9282bb-2f34-4de9-879d-0b32b5d037c0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
								
									
									
									 
									 
									Forgot Password ?
								
							' or . = '
								
									
									
									 
									 
									Forgot Password ?
								
							')]</value>
      <webElementGuid>117d8363-05f5-4d9f-a3cc-58b2fb2b6a30</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
