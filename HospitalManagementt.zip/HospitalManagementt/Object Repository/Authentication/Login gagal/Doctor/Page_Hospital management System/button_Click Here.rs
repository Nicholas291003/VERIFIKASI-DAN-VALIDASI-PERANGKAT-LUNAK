<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Click Here</name>
   <tag></tag>
   <elementGuidId>716026f2-07cf-4287-8c07-e6dc3e882e54</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='logins']/div/div[2]/div/div[2]/div/div/a/button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;Click Here&quot;i] >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>6f16c124-1a89-45ef-80f5-7847cd43f280</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-success btn-sm</value>
      <webElementGuid>e61305c0-60a4-4018-9c26-a6fd6da9b3ef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Click Here</value>
      <webElementGuid>2af28504-8374-427d-a03b-f85494bff915</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;logins&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;col-sm-12 blog-cont&quot;]/div[@class=&quot;row no-margin&quot;]/div[@class=&quot;col-sm-4 blog-smk&quot;]/div[@class=&quot;blog-single&quot;]/div[@class=&quot;blog-single-det&quot;]/a[1]/button[@class=&quot;btn btn-success btn-sm&quot;]</value>
      <webElementGuid>4a57bf55-cb51-4062-a961-41d4d2e8819f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='logins']/div/div[2]/div/div[2]/div/div/a/button</value>
      <webElementGuid>2a0b2667-b07e-4f8b-be35-9db07a1dee8a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Doctors login'])[1]/following::button[1]</value>
      <webElementGuid>a4bd316d-7319-44e6-9841-38300cbede87</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click Here'])[1]/following::button[1]</value>
      <webElementGuid>418e49de-cf7e-4ed9-acda-66da3fe5b9a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Admin Login'])[1]/preceding::button[1]</value>
      <webElementGuid>146c63c2-0355-4094-a001-e443c6b90441</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click Here'])[3]/preceding::button[1]</value>
      <webElementGuid>5b37f046-85c1-407b-af39-c4ff59a0f958</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/a/button</value>
      <webElementGuid>a81782ba-6492-46a2-9769-955632efb00c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Click Here' or . = 'Click Here')]</value>
      <webElementGuid>f0e43c83-d515-437b-b115-bef332586a6d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
