<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Password Changed Successfully Current P_ab5742</name>
   <tag></tag>
   <elementGuidId>f695cd34-a28a-4ff0-9699-9e77bfded5aa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.panel-body</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='container']/div/div/div/div/div/div/div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Password Changed Successfully !! Current Password New Password Confirm Password &quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>04480e62-455d-4945-ae8d-55a89ef84711</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>panel-body</value>
      <webElementGuid>557e3b55-46b4-4b61-a6b5-91be388bef57</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
								Password Changed Successfully !!									
													
														
															
																Current Password
															
							
														
														
															
																New Password
															
					
														
														

															
																Confirm Password
															
									
														
														
														
														
														
															Submit
														
													
												</value>
      <webElementGuid>d47c4061-4b37-4c0c-ac02-a9408ece0cee</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;container&quot;)/div[@class=&quot;container-fluid container-fullw bg-white&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;row margin-top-30&quot;]/div[@class=&quot;col-lg-8 col-md-12&quot;]/div[@class=&quot;panel panel-white&quot;]/div[@class=&quot;panel-body&quot;]</value>
      <webElementGuid>372763b6-af20-442b-bdf4-9e5fb81d38ed</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='container']/div/div/div/div/div/div/div[2]</value>
      <webElementGuid>bd671a1d-fbff-4c96-a438-14cab5c17bba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Change Password'])[3]/following::div[1]</value>
      <webElementGuid>429d5498-0955-477c-bbaf-d8617a8cbaf8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Change Password'])[2]/following::div[8]</value>
      <webElementGuid>3f90741b-6c99-4945-bfea-d6c687194068</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/div/div[2]</value>
      <webElementGuid>65dd37d0-0996-4498-bda5-846728c38f80</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
								Password Changed Successfully !!									
													
														
															
																Current Password
															
							
														
														
															
																New Password
															
					
														
														

															
																Confirm Password
															
									
														
														
														
														
														
															Submit
														
													
												' or . = '
								Password Changed Successfully !!									
													
														
															
																Current Password
															
							
														
														
															
																New Password
															
					
														
														

															
																Confirm Password
															
									
														
														
														
														
														
															Submit
														
													
												')]</value>
      <webElementGuid>dd934f23-9aad-446d-8d7a-d262e3340452</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
