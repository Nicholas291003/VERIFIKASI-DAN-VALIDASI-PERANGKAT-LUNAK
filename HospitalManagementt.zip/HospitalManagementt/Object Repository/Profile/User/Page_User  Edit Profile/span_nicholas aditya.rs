<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_nicholas aditya</name>
   <tag></tag>
   <elementGuidId>2bfd1322-8388-4e31-b15e-d0dfcdcd00e0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.username</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='app']/div[2]/header/div[2]/ul/li[2]/a/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;nicholas aditya &quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>b22303a2-2655-4ed1-a9c0-2aee6ad419e0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>username</value>
      <webElementGuid>6fcbc076-a523-46aa-83ea-e6a4bf5b4ea0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>



									nicholas aditya </value>
      <webElementGuid>5fe4e513-9ffb-44ce-8c0e-229e40bbd6f0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[@class=&quot;app-content&quot;]/header[@class=&quot;navbar navbar-default navbar-static-top&quot;]/div[@class=&quot;navbar-collapse collapse&quot;]/ul[@class=&quot;nav navbar-right&quot;]/li[@class=&quot;dropdown current-user&quot;]/a[@class=&quot;dropdown-toggle&quot;]/span[@class=&quot;username&quot;]</value>
      <webElementGuid>1502d4d1-c12f-4455-af5d-2036f88488ba</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='app']/div[2]/header/div[2]/ul/li[2]/a/span</value>
      <webElementGuid>eb87c247-ff63-4e1c-b22e-bff2f9adb39f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Hospital Management System'])[1]/following::span[1]</value>
      <webElementGuid>167d084c-4175-41da-8900-649365ce59fd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Toggle navigation'])[1]/following::span[1]</value>
      <webElementGuid>cc6207b2-9bdf-4499-91e3-68dabd8c07c2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='My Profile'])[1]/preceding::span[1]</value>
      <webElementGuid>b78d1d32-9f87-419b-b520-b9a4e2035b05</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Change Password'])[1]/preceding::span[1]</value>
      <webElementGuid>2122ccda-6317-4655-b74b-6ff0c91f73b7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='nicholas aditya']/parent::*</value>
      <webElementGuid>c1b1ba8e-5ae0-43f7-8f48-fa8fd649402e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/a/span</value>
      <webElementGuid>ef06f30e-6a92-45fd-be96-7209a2f24448</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '



									nicholas aditya ' or . = '



									nicholas aditya ')]</value>
      <webElementGuid>fca81004-ae66-4c81-b71e-da8b3a4a64bd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
