<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Change Password</name>
   <tag></tag>
   <elementGuidId>5b76df06-647d-4b12-8b06-429c08af3d14</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.dropdown-menu.dropdown-dark > li:nth-of-type(2) > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='app']/div[2]/header/div[2]/ul/li[2]/ul/li[2]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Change Password&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>52dcd43a-a0c8-42e3-b39c-3e7c3e508ce8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>change-password.php</value>
      <webElementGuid>32657836-959b-4dc6-ae8a-d4bce493b4ad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
											Change Password
										</value>
      <webElementGuid>1476a2a9-cc5e-46bf-b7d5-1ee6f2ce5b7e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[@class=&quot;app-content&quot;]/header[@class=&quot;navbar navbar-default navbar-static-top&quot;]/div[@class=&quot;navbar-collapse collapse&quot;]/ul[@class=&quot;nav navbar-right&quot;]/li[@class=&quot;dropdown current-user open&quot;]/ul[@class=&quot;dropdown-menu dropdown-dark&quot;]/li[2]/a[1]</value>
      <webElementGuid>b4a114f8-c73a-4960-abdd-2cbf1a8b4231</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='app']/div[2]/header/div[2]/ul/li[2]/ul/li[2]/a</value>
      <webElementGuid>f4702f78-1e1f-4753-bac5-a1aba615183c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Change Password')]</value>
      <webElementGuid>3c856dd5-036a-4ddb-8786-ead3ca05c590</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='My Profile'])[1]/following::a[1]</value>
      <webElementGuid>5856e265-1f57-4511-b880-2213819351c1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='nicholas aditya'])[1]/following::a[2]</value>
      <webElementGuid>7dcedb58-1db2-4b1d-8e16-6f8662dbc8d8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Log Out'])[1]/preceding::a[1]</value>
      <webElementGuid>347046fb-7509-44e2-b0d2-3f4ee39af871</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='User | Edit Profile'])[2]/preceding::a[2]</value>
      <webElementGuid>2396cf0c-6b0c-4fa6-b3c1-b42f16396495</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Change Password']/parent::*</value>
      <webElementGuid>437332b2-f61b-4022-98e5-7f0e5cbc0b02</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'change-password.php')]</value>
      <webElementGuid>23e12089-7644-4616-8032-221b83e0ed1e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/ul/li[2]/a</value>
      <webElementGuid>c688997a-a895-4ba4-b1aa-9faabf5972ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'change-password.php' and (text() = '
											Change Password
										' or . = '
											Change Password
										')]</value>
      <webElementGuid>0189c55b-c648-4ff5-8e69-af8873485052</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
