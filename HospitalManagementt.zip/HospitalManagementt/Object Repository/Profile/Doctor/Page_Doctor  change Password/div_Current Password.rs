<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Current Password</name>
   <tag></tag>
   <elementGuidId>800396f1-39bd-4995-ab89-d4b658766721</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.form-group</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='container']/div/div/div/div/div/div/div[2]/form/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=form >> div >> internal:has-text=&quot;Current Password&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>6ce5d27f-43b9-4cd3-801a-4cc7c7db9807</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-group</value>
      <webElementGuid>95d0ce74-146f-43b8-b577-0d5bfed0ba76</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
															
																Current Password
															
							
														</value>
      <webElementGuid>ec37ccf7-43f0-4c48-9c09-ccb9fb3aaa7a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;container&quot;)/div[@class=&quot;container-fluid container-fullw bg-white&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;row margin-top-30&quot;]/div[@class=&quot;col-lg-8 col-md-12&quot;]/div[@class=&quot;panel panel-white&quot;]/div[@class=&quot;panel-body&quot;]/form[1]/div[@class=&quot;form-group&quot;]</value>
      <webElementGuid>8d8dc26f-5189-450d-9bc5-2b6eeec2528d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='container']/div/div/div/div/div/div/div[2]/form/div</value>
      <webElementGuid>4c5c9692-ae93-493d-8eaa-68794070922d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Change Password'])[3]/following::div[2]</value>
      <webElementGuid>65a59693-54ef-44dd-b794-191d9ec06167</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Change Password'])[2]/following::div[9]</value>
      <webElementGuid>c4faa296-f804-4c95-aeb6-b523bb25562f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New Password'])[1]/preceding::div[1]</value>
      <webElementGuid>aa2663e0-67cc-4f0f-96d4-6823eb36adfb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/div</value>
      <webElementGuid>09e0a6d7-2639-4451-b6c8-0b7412f2ffab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
															
																Current Password
															
							
														' or . = '
															
																Current Password
															
							
														')]</value>
      <webElementGuid>7c0511a2-b5c0-4ac2-81dd-6ae6e1c24fd6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
