<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Change Password</name>
   <tag></tag>
   <elementGuidId>c3ed12c2-7e61-45d0-8753-a61d93d220cb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.dropdown-menu.dropdown-dark > li > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='app']/div[2]/header/div[2]/ul/li[2]/ul/li/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Change Password&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>3f42a602-7a1c-4ade-88cc-774d9ed26b0b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>change-password.php</value>
      <webElementGuid>37217a8c-057c-4212-a94f-0e84288f9c92</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
											Change Password
										</value>
      <webElementGuid>33ea6599-0d2d-41da-b3be-5a67d0d5718d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[@class=&quot;app-content&quot;]/header[@class=&quot;navbar navbar-default navbar-static-top&quot;]/div[@class=&quot;navbar-collapse collapse&quot;]/ul[@class=&quot;nav navbar-right&quot;]/li[@class=&quot;dropdown current-user open&quot;]/ul[@class=&quot;dropdown-menu dropdown-dark&quot;]/li[1]/a[1]</value>
      <webElementGuid>dabe6c76-6183-49c6-b31a-e689c95d0b87</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='app']/div[2]/header/div[2]/ul/li[2]/ul/li/a</value>
      <webElementGuid>4afea78f-ffa8-4798-bd9c-918e82f67d9c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Change Password')]</value>
      <webElementGuid>25e662ea-80bf-41db-91cc-1c1163179ee9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Admin'])[1]/following::a[1]</value>
      <webElementGuid>2d50ce50-73cb-4991-9630-d5eb11788164</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Hospital Management System'])[1]/following::a[2]</value>
      <webElementGuid>7542de86-e550-4610-82df-99010872d389</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Log Out'])[1]/preceding::a[1]</value>
      <webElementGuid>a00da0d8-08fa-4319-bd53-1c43157b2c2c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Admin | Dashboard'])[2]/preceding::a[2]</value>
      <webElementGuid>dff7852d-d167-437c-9524-cd4ed3e4ee43</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Change Password']/parent::*</value>
      <webElementGuid>6470890b-53c0-4354-844c-5b6893c8fda5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'change-password.php')]</value>
      <webElementGuid>afa55550-f603-4b85-bd35-b38a199b51d1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul/li[2]/ul/li/a</value>
      <webElementGuid>21d25322-f422-47d7-8f87-576781e537b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'change-password.php' and (text() = '
											Change Password
										' or . = '
											Change Password
										')]</value>
      <webElementGuid>9e115389-cc6b-4132-b579-f1057cfadea7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
