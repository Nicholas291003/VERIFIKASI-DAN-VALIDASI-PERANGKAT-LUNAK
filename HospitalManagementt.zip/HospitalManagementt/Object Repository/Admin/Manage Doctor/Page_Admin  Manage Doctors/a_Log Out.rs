<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Log Out</name>
   <tag></tag>
   <elementGuidId>73fd4661-97a7-42db-b906-43041171b535</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.dropdown-menu.dropdown-dark > li:nth-of-type(2) > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='app']/div[2]/header/div[2]/ul/li[2]/ul/li[2]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Log Out&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>b98b3b6d-95c2-47e7-ac92-54b487982858</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>logout.php</value>
      <webElementGuid>7d1c0d67-06a6-4b8e-b2be-04fd7abae7c8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
											Log Out
										</value>
      <webElementGuid>933be4e6-a9ca-4cff-8fcc-43d8aa7f6b68</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[@class=&quot;app-content&quot;]/header[@class=&quot;navbar navbar-default navbar-static-top&quot;]/div[@class=&quot;navbar-collapse collapse&quot;]/ul[@class=&quot;nav navbar-right&quot;]/li[@class=&quot;dropdown current-user open&quot;]/ul[@class=&quot;dropdown-menu dropdown-dark&quot;]/li[2]/a[1]</value>
      <webElementGuid>5e7069f7-6933-40aa-a7c2-efe4d97b2130</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='app']/div[2]/header/div[2]/ul/li[2]/ul/li[2]/a</value>
      <webElementGuid>740cf846-3300-4298-a507-744b4c19a361</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Log Out')]</value>
      <webElementGuid>9ca09313-b124-4ce6-9747-c0dbee96ad80</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Change Password'])[1]/following::a[1]</value>
      <webElementGuid>affa2848-f6ea-4e88-81a7-549d4c316fef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Admin'])[1]/following::a[2]</value>
      <webElementGuid>58b17ec1-5e49-4222-8b6a-a711320b10b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Admin | Manage Doctors'])[2]/preceding::a[1]</value>
      <webElementGuid>3546ddad-79f0-4e67-9232-714e5f37034b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Admin'])[2]/preceding::a[1]</value>
      <webElementGuid>b889baa3-5583-457a-8251-121cfd1100b5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Log Out']/parent::*</value>
      <webElementGuid>c4585860-8f0e-43d3-902c-12db1099da62</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'logout.php')]</value>
      <webElementGuid>4082c4c7-c045-471c-bab5-35fd1c9fc565</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul/li[2]/ul/li[2]/a</value>
      <webElementGuid>677049fc-55ec-49dd-b01e-efeecc2a97e3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'logout.php' and (text() = '
											Log Out
										' or . = '
											Log Out
										')]</value>
      <webElementGuid>567cde98-a0d8-4a35-b3ba-c4356c0918a6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
