<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i_dr.paijo slamet_fa fa-times fa fa-white</name>
   <tag></tag>
   <elementGuidId>d386f21e-fcc0-41bc-9c72-73a76a885124</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(4) > td:nth-of-type(5) > div.visible-md.visible-lg.hidden-sm.hidden-xs > a.btn.btn-transparent.btn-xs.tooltips > i.fa.fa-times.fa.fa-white</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//table[@id='sample-table-1']/tbody/tr[4]/td[5]/div/a[2]/i</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;&quot;i] >> nth=3</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
      <webElementGuid>aef86b37-dbd2-4740-97f3-6121c14f9b7b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fa fa-times fa fa-white</value>
      <webElementGuid>74e24955-0ff3-4f9f-99d6-11154a95cc3e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sample-table-1&quot;)/tbody[1]/tr[4]/td[5]/div[@class=&quot;visible-md visible-lg hidden-sm hidden-xs&quot;]/a[@class=&quot;btn btn-transparent btn-xs tooltips&quot;]/i[@class=&quot;fa fa-times fa fa-white&quot;]</value>
      <webElementGuid>ab1cccd9-1f60-4b12-ab21-a44ad835cda7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//table[@id='sample-table-1']/tbody/tr[4]/td[5]/div/a[2]/i</value>
      <webElementGuid>4e63f504-05ef-4207-a4f4-0d30def55969</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[4]/td[5]/div/a[2]/i</value>
      <webElementGuid>71341a81-3763-417f-9fac-b63c78a2b34a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
