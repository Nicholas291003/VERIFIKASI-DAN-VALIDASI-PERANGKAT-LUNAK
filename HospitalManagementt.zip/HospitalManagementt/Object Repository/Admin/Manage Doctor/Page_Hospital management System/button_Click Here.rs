<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Click Here</name>
   <tag></tag>
   <elementGuidId>17f1ef36-f277-4c60-9c7c-aa77e12e6459</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='logins']/div/div[2]/div/div[3]/div/div/a/button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;Click Here&quot;i] >> nth=2</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>445ca6a1-7803-4ce7-8bd0-596e9bff5ec1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-success btn-sm</value>
      <webElementGuid>96fd6cf8-042b-4be8-967c-13c4ce1cda1e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Click Here</value>
      <webElementGuid>a38502bf-f296-4b13-bf85-96144968cbf6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;logins&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;col-sm-12 blog-cont&quot;]/div[@class=&quot;row no-margin&quot;]/div[@class=&quot;col-sm-4 blog-smk&quot;]/div[@class=&quot;blog-single&quot;]/div[@class=&quot;blog-single-det&quot;]/a[1]/button[@class=&quot;btn btn-success btn-sm&quot;]</value>
      <webElementGuid>e4b45c6a-a001-42d1-b866-0ced7e820803</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='logins']/div/div[2]/div/div[3]/div/div/a/button</value>
      <webElementGuid>c5b32c1d-5106-4b15-8f4f-a353e04c3ed8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Admin Login'])[1]/following::button[1]</value>
      <webElementGuid>f38d2c04-d479-4a2e-a604-964e3e6dc232</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click Here'])[2]/following::button[1]</value>
      <webElementGuid>ad48813f-61cf-4777-8a1e-56cb920bcb70</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Our Key Features'])[1]/preceding::button[1]</value>
      <webElementGuid>df95764e-599a-446c-aec8-5a0097b821e4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cardiology'])[1]/preceding::button[1]</value>
      <webElementGuid>39155c1d-81cf-47c0-b661-ebc7327ff152</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/a/button</value>
      <webElementGuid>a16400b3-4e92-445e-9d5f-71f23a4beb13</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Click Here' or . = 'Click Here')]</value>
      <webElementGuid>f7cd0c20-e22d-4caa-b90b-c3ae464c0075</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
