<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i_Login_fa fa-arrow-circle-right</name>
   <tag></tag>
   <elementGuidId>3bf36525-2b11-4c10-b778-07ff74320002</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>i.fa.fa-arrow-circle-right</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button/i</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;Login &quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
      <webElementGuid>cd7824ed-e0fa-4093-b2fd-4b79efbe7e07</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fa fa-arrow-circle-right</value>
      <webElementGuid>3751bd33-fa8d-4d4b-a9f0-156a523d1a42</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths&quot;]/body[@class=&quot;login&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;main-login col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4&quot;]/div[@class=&quot;box-login&quot;]/form[@class=&quot;form-login&quot;]/fieldset[1]/div[@class=&quot;form-actions&quot;]/button[@class=&quot;btn btn-primary pull-right&quot;]/i[@class=&quot;fa fa-arrow-circle-right&quot;]</value>
      <webElementGuid>fc49b1e4-8537-4bfc-8116-3ad341768a50</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button/i</value>
      <webElementGuid>24d65fd1-3b33-4596-956b-aa6cc173277f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
