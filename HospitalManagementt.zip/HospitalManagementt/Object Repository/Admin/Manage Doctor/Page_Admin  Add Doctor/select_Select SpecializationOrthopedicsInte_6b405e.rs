<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Select SpecializationOrthopedicsInte_6b405e</name>
   <tag></tag>
   <elementGuidId>97f49985-45fa-48bf-9935-5c083231dd94</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>select[name=&quot;Doctorspecialization&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@name='Doctorspecialization']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=combobox</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>734b0f0b-f498-4081-ac3b-347f1b380e19</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>Doctorspecialization</value>
      <webElementGuid>4323f8da-acc1-4baa-a96e-4a7a3623737c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
      <webElementGuid>6afbff79-7fcb-453e-80da-32c81507bc01</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>required</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>921a8571-945a-42ca-80c1-0f59bcb007cf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
																Select Specialization
																
																	Orthopedics																
																																
																	Internal Medicine																
																																
																	Obstetrics and Gynecology																
																																
																	Dermatology																
																																
																	Pediatrics																
																																
																	Radiology																
																																
																	General Surgery																
																																
																	Ophthalmology																
																																
																	Anesthesia																
																																
																	Pathology																
																																
																	ENT																
																																
																	Dental Care																
																																
																	Dermatologists																
																																
																	Endocrinologists																
																																
																	Neurologists																
																																
															</value>
      <webElementGuid>10d29b8c-4a6e-4bee-9617-cf52451a6db0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;container&quot;)/div[@class=&quot;container-fluid container-fullw bg-white&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;row margin-top-30&quot;]/div[@class=&quot;col-lg-8 col-md-12&quot;]/div[@class=&quot;panel panel-white&quot;]/div[@class=&quot;panel-body&quot;]/form[1]/div[@class=&quot;form-group&quot;]/select[@class=&quot;form-control&quot;]</value>
      <webElementGuid>3d5be6c8-3ae2-41c3-b966-6514ff39ee0c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@name='Doctorspecialization']</value>
      <webElementGuid>5b98aa2f-31e3-4ee2-81a6-b9c302d3d41b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='container']/div/div/div/div/div/div/div[2]/form/div/select</value>
      <webElementGuid>66e06483-4172-4620-800e-8cc710cd09d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Doctor Specialization'])[2]/following::select[1]</value>
      <webElementGuid>e4d9e3f3-cf9c-44db-8192-0603d4e44037</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add Doctor'])[3]/following::select[1]</value>
      <webElementGuid>7f00721c-41ed-4251-abd4-88a0cb250727</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Doctor Name'])[1]/preceding::select[1]</value>
      <webElementGuid>e5bc25a3-f47f-48b5-993b-09c00799189d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Doctor Clinic Address'])[1]/preceding::select[1]</value>
      <webElementGuid>9b74c76d-5864-4a64-b3de-5caf2044b094</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>fe2a8878-c4c6-43e0-af70-fb025be89f30</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'Doctorspecialization' and (text() = '
																Select Specialization
																
																	Orthopedics																
																																
																	Internal Medicine																
																																
																	Obstetrics and Gynecology																
																																
																	Dermatology																
																																
																	Pediatrics																
																																
																	Radiology																
																																
																	General Surgery																
																																
																	Ophthalmology																
																																
																	Anesthesia																
																																
																	Pathology																
																																
																	ENT																
																																
																	Dental Care																
																																
																	Dermatologists																
																																
																	Endocrinologists																
																																
																	Neurologists																
																																
															' or . = '
																Select Specialization
																
																	Orthopedics																
																																
																	Internal Medicine																
																																
																	Obstetrics and Gynecology																
																																
																	Dermatology																
																																
																	Pediatrics																
																																
																	Radiology																
																																
																	General Surgery																
																																
																	Ophthalmology																
																																
																	Anesthesia																
																																
																	Pathology																
																																
																	ENT																
																																
																	Dental Care																
																																
																	Dermatologists																
																																
																	Endocrinologists																
																																
																	Neurologists																
																																
															')]</value>
      <webElementGuid>d74360e0-6e95-411f-b8b6-5cef99b98aa1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
