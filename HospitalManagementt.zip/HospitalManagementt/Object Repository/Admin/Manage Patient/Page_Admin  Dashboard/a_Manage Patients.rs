<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Manage Patients</name>
   <tag></tag>
   <elementGuidId>1af60f8c-db89-4add-95fa-3942361bc795</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.open > ul.sub-menu > li > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='sidebar']/div/nav/ul/li[4]/ul/li/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Manage Patients&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>60179d39-1cb4-4f6b-b60e-4f1c288e206f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>manage-patient.php</value>
      <webElementGuid>0f0ba9b0-f4cb-4871-9bad-eae75e8ae790</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
											 Manage Patients 
										</value>
      <webElementGuid>c8e37c6d-d5bb-48bd-afd0-bc915b9d59ab</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sidebar&quot;)/div[@class=&quot;sidebar-container perfect-scrollbar ps-container&quot;]/nav[1]/ul[@class=&quot;main-navigation-menu&quot;]/li[@class=&quot;open&quot;]/ul[@class=&quot;sub-menu&quot;]/li[1]/a[1]</value>
      <webElementGuid>0606ef65-3987-48ee-822b-1ad904bf33b6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='sidebar']/div/nav/ul/li[4]/ul/li/a</value>
      <webElementGuid>bafeb980-1b0d-4bb1-a84e-63f6fcbd50e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Patients'])[1]/following::a[1]</value>
      <webElementGuid>558ed99a-de17-42ad-81cd-c1219da00e01</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Manage Users'])[1]/following::a[2]</value>
      <webElementGuid>f1147e39-7f2b-44be-b221-cb6cd2a27293</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Appointment History'])[1]/preceding::a[1]</value>
      <webElementGuid>07dfe9e4-8cbd-46f0-b061-5fe8a52088d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'manage-patient.php')]</value>
      <webElementGuid>c2c86dea-1c2f-456e-9c49-46426033fc5d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[4]/ul/li/a</value>
      <webElementGuid>08fe6cd9-59b3-4a2b-ad32-6c9813b4bbee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'manage-patient.php' and (text() = '
											 Manage Patients 
										' or . = '
											 Manage Patients 
										')]</value>
      <webElementGuid>f745478f-2aba-48a5-a202-1a8cff0a9991</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
