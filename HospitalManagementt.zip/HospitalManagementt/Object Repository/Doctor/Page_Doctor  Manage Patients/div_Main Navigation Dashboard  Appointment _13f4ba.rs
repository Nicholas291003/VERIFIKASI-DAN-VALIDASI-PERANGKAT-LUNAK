<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Main Navigation Dashboard  Appointment _13f4ba</name>
   <tag></tag>
   <elementGuidId>5f0f44bc-08cc-4d16-ba39-4507df25c46a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#app</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='app']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Main Navigation Dashboard Appointment History Patients Manage Patient HMS Toggle&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>0b4d11b5-1035-4609-9634-5a5840aa4867</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>app</value>
      <webElementGuid>c9b190f9-772a-496f-9a46-a1a08725e657</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>app-navbar-fixed app-sidebar-fixed</value>
      <webElementGuid>2b455ab2-5a6c-4d5b-92b6-ee9b53da63b3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>		

				


						
						
						
							Main Navigation
						
						
							
								
									
										
											
										
										
											 Dashboard 
										
									
								
							
							

							
								
									
										
											
										
										
											 Appointment History 
										
									
								
							
							
								
									
										
											
										
										
											 Patients 
										
									
								
								
									
									
									
										
											 Manage Patient 
										
									
									
								
								

								

						
						
						
					
					
			

					
					
						
							
						
						
							HMS
						
						
							
						
						
							Toggle navigation
							
						
					
					
					
					
						
							
								
								Hospital Management System
							
						
						
							
								
									 



									Dr. Andi Wijaya, Sp.OT 
								
								
									
										
											My Profile
										
									
								
									
										
											Change Password
										
									
									
										
											Log Out
										
									
								
							
							
						
						
						
							
							
						
						
					
				
					
					
				


						



Doctor | Manage Patients



Doctor


Manage Patients







Manage Patients
	



#
Patient Name
Patient Contact Number
Patient Gender 
Creation Date 
Updation Date 
Action











</value>
      <webElementGuid>72e9f333-6d52-4136-937d-3ab76465bfee</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)</value>
      <webElementGuid>2b4df225-0f20-465c-b86c-98d29a9126c4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='app']</value>
      <webElementGuid>bf49bf37-0811-433c-97d7-f36e566eb71c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div</value>
      <webElementGuid>9e3682d5-80ff-478f-87d7-2252aa0448ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[@id = 'app' and (text() = '		

				


						
						
						
							Main Navigation
						
						
							
								
									
										
											
										
										
											 Dashboard 
										
									
								
							
							

							
								
									
										
											
										
										
											 Appointment History 
										
									
								
							
							
								
									
										
											
										
										
											 Patients 
										
									
								
								
									
									
									
										
											 Manage Patient 
										
									
									
								
								

								

						
						
						
					
					
			

					
					
						
							
						
						
							HMS
						
						
							
						
						
							Toggle navigation
							
						
					
					
					
					
						
							
								
								Hospital Management System
							
						
						
							
								
									 



									Dr. Andi Wijaya, Sp.OT 
								
								
									
										
											My Profile
										
									
								
									
										
											Change Password
										
									
									
										
											Log Out
										
									
								
							
							
						
						
						
							
							
						
						
					
				
					
					
				


						



Doctor | Manage Patients



Doctor


Manage Patients







Manage Patients
	



#
Patient Name
Patient Contact Number
Patient Gender 
Creation Date 
Updation Date 
Action











' or . = '		

				


						
						
						
							Main Navigation
						
						
							
								
									
										
											
										
										
											 Dashboard 
										
									
								
							
							

							
								
									
										
											
										
										
											 Appointment History 
										
									
								
							
							
								
									
										
											
										
										
											 Patients 
										
									
								
								
									
									
									
										
											 Manage Patient 
										
									
									
								
								

								

						
						
						
					
					
			

					
					
						
							
						
						
							HMS
						
						
							
						
						
							Toggle navigation
							
						
					
					
					
					
						
							
								
								Hospital Management System
							
						
						
							
								
									 



									Dr. Andi Wijaya, Sp.OT 
								
								
									
										
											My Profile
										
									
								
									
										
											Change Password
										
									
									
										
											Log Out
										
									
								
							
							
						
						
						
							
							
						
						
					
				
					
					
				


						



Doctor | Manage Patients



Doctor


Manage Patients







Manage Patients
	



#
Patient Name
Patient Contact Number
Patient Gender 
Creation Date 
Updation Date 
Action











')]</value>
      <webElementGuid>fe620b17-0b8e-45e3-b1e8-c9e831efc704</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
