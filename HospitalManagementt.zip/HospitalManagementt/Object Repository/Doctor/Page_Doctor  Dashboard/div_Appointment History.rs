<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Appointment History</name>
   <tag></tag>
   <elementGuidId>34b4377c-44f9-43a7-a564-783f02712d26</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(2) > a > div.item-content > div.item-inner</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='sidebar']/div/nav/ul/li[2]/a/div/div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot; Appointment History&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>d2b23468-bc2a-4699-8285-629d8434f268</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>item-inner</value>
      <webElementGuid>4b907459-a90b-4903-a4ec-753660fc9071</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
											 Appointment History 
										</value>
      <webElementGuid>74431f35-5fd7-4585-bbdf-e6843245953a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sidebar&quot;)/div[@class=&quot;sidebar-container perfect-scrollbar ps-container&quot;]/nav[1]/ul[@class=&quot;main-navigation-menu&quot;]/li[2]/a[1]/div[@class=&quot;item-content&quot;]/div[@class=&quot;item-inner&quot;]</value>
      <webElementGuid>fb6ef8fe-def7-450a-9711-ed5e29f0701a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='sidebar']/div/nav/ul/li[2]/a/div/div[2]</value>
      <webElementGuid>7f0141b5-47a9-4f7c-bbe2-6da55909d8ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/following::div[3]</value>
      <webElementGuid>fc0c4269-eb47-4b2a-aa1f-e49d68c1baf0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Main Navigation'])[1]/following::div[6]</value>
      <webElementGuid>3099dd86-54e6-4919-9f88-2e2fc95cb180</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Patients'])[1]/preceding::div[2]</value>
      <webElementGuid>9a215e4e-f37c-4729-889c-ddef2c229958</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/a/div/div[2]</value>
      <webElementGuid>78d7d8ca-b011-4990-bf84-8e751319623c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
											 Appointment History 
										' or . = '
											 Appointment History 
										')]</value>
      <webElementGuid>f5cff371-3ac6-4fdc-866b-8cd8c1afe028</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
